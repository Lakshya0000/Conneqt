


export {uploadToIpfs, uploadToIpfsJson,getJsonFromIpfs} from "./pinata"
