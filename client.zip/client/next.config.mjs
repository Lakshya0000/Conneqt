/** @type {import('next').NextConfig} */
const nextConfig = {
    images: {
        domains: ['images.unsplash.com','ipfs.io'],
    },
};

export default nextConfig;
